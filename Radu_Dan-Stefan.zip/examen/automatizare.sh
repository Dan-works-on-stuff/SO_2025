#!/bin/bash

echo "Input a nr (p)" > $p

if [ find script.c ]; then


fi

#no_more_time :(
